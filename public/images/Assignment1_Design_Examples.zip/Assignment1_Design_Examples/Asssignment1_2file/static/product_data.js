
var products = 
[
    {
    "brand": "HTC",
    "price": 40.00,
    "image": "http://dport96.github.io/ITM352/morea/080.flow-control-II/HTC.jpg"
    },
    {
    "brand": "Apple",
    "price": 75.00,
    "image": "http://dport96.github.io/ITM352/morea/080.flow-control-II/iphone-3gs.jpg"
    },
    {
    "brand": "Nokia",
    "price": 35.00,
    "image": "http://dport96.github.io/ITM352/morea/080.flow-control-II/Nokia.jpg"
    },
    {
    "brand": "Samsung",
    "price": 45.00,
    "image": "http://dport96.github.io/ITM352/morea/080.flow-control-II/Samsung.jpg"
    },
    {
    "brand": "Blackberry",
    "price": 10.00,
    "image": "http://dport96.github.io/ITM352/morea/080.flow-control-II/Blackberry.jpg"
    }
];
if(typeof module != 'undefined') {
    module.exports.products = products;
  }